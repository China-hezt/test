#!/usr/bin/bash

if ps axf | grep -q postmaster; then
    if ps axf | grep "wal sender" | grep -v -q grep; then
        echo "pg master"
    else
        echo "pg slave"
    fi
else
    echo "pg down"
fi

st=`redis-cli get "shterm:ha:node:state"`
if [ "$st" = "m" ]; then
    echo "node master"
elif [ "$st" = "s" ]; then
    echo "node slave"
elif [ "$st" = 'd' ]; then
    echo "node down"
else
    echo "node unkown"
fi
