#!/bin/bash

master=`cat /etc/shterm/haconfig | awk -F'"' '/"master"/ {print $4}'`
standby=`cat /etc/shterm/haconfig | awk -F'"' '/"standby"/ {print $4}'`
parent_node=`cat /etc/shterm/haconfig | awk -F'"' '/"parent_node_ip"/ {print $4}'`
pg_port_ha=9999
if [ -z "$master" -o -z "standby" ]; then
    echo "config data is invalid"
    exit 1
fi

reset_redis() {
    /usr/bin/redis-cli del "shterm:ha:info"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:demote"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:node:state"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:maintenance-mode"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:common:monitor:ha"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:internal:peernode"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:temp-write"  >/dev/null 2>&1
    /usr/bin/redis-cli del "shterm:ha:promote"  >/dev/null 2>&1
}

cat /etc/shterm/haconfig | grep "is_master" | grep -iq "true"
if [ $? -eq 0 ]; then
    echo "to init master"
    ifconfig | grep -q " $master "
    if [ $? -ne 0 ]; then
        echo "master ip($master) is invalid"
        exit 1
    fi
    
    reset_redis

    if [ ! -z "$parent_node" ]; then
        /usr/libexec/shterm/ha_script pg_stop_if
        /usr/libexec/shterm/ha_script pg_restore $parent_node
        if [ $? -ne 0 ]; then
            echo "ERROR: restore master data(is parent node(DB) online?)"
            exit 1
        fi
        /usr/libexec/shterm/ha_script make_recovery $parent_node $master
    fi
else
    echo "to init standby"
    ifconfig | grep -q " $standby "
    if [ $? -ne 0 ]; then
        echo "standby ip($standby) is invalid"
        exit 1
    fi
    
    reset_redis
    
    /usr/libexec/shterm/ha_script pg_stop_if

    if [ ! -z "$parent_node" ]; then
        /usr/libexec/shterm/ha_script pg_restore $master $pg_port_ha
    else
        /usr/libexec/shterm/ha_script pg_restore $master $pg_port_ha
    fi

    if [ $? -ne 0 ]; then
        echo "ERROR: restore standby data(is master node(DB) online?)"
        exit 1
    fi

    if [ ! -z "$parent_node" ]; then
        # config_pgpool set pg port 9999 when parent node exists
        /usr/libexec/shterm/ha_script make_recovery $master $standby $pg_port_ha
    else
        /usr/libexec/shterm/ha_script make_recovery $master $standby $pg_port_ha
    fi

fi

echo "init done"

