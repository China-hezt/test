#!/usr/bin/bash

make_key()
{
	usermod shterm -s /bin/bash > /dev/null 2>&1
	[ -d /home/shterm/.ssh ] || mkdir -p /home/shterm/.ssh
	[ -d /home/shterm/.ssh ] && chown shterm.shterm /home/shterm/.ssh
	[ -d /home/shterm/.ssh ] && chmod 700 /home/shterm/.ssh
	[ -f /home/shterm/.ssh/authorized_keys ] || touch /home/shterm/.ssh/authorized_keys
	[ -f /home/shterm/.ssh/authorized_keys ] && chown shterm.shterm /home/shterm/.ssh/authorized_keys
	[ -f /home/shterm/.ssh/authorized_keys ] && chmod 600 /home/shterm/.ssh/authorized_keys
	sudo -u shterm ssh-keygen -t rsa -b 2048 -N "" -f /home/shterm/.ssh/id_rsa
	cat /home/shterm/.ssh/id_rsa.pub >> /home/shterm/.ssh/authorized_keys
}

copy_key()
{
	SSH_KEY_PATH=/home/shterm/.ssh
	usermod shterm -s /bin/bash > /dev/null 2>&1
	[ -d /home/shterm/.ssh ] || mkdir -p $SSH_KEY_PATH
	[ -d /home/shterm/.ssh ] && chown shterm.shterm $SSH_KEY_PATH
	[ -d /home/shterm/.ssh ] && chmod 700 $SSH_KEY_PATH
	cp id_rsa* authorized_keys $SSH_KEY_PATH
	chmod 600 $SSH_KEY_PATH/authorized_keys $SSH_KEY_PATH/id_rsa
	chmod 644 $SSH_KEY_PATH/id_rsa.pub
	chown shterm.shterm $SSH_KEY_PATH/authorized_keys $SSH_KEY_PATH/id_rsa $SSH_KEY_PATH/id_rsa.pub
}

eval "$1"