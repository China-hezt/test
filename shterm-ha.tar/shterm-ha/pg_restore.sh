#!/usr/bin/bash

restore=1

BIN_DIR=/usr/pgsql-9.6/bin
DATA_DIR=/var/lib/pgsql/9.6/data
DATA_DIR_BACKUP=/var/lib/pgsql/9.6/data

if [ -z "$1" ]; then
    echo "Usage: pg_restore.sh ip"
    exit 1
else
    server_ip=$1
    server_port=$2
fi

tmp_name=`date +"%Y%m%d-%H%M%S"`
tmp_name="${DATA_DIR_BACKUP}_$tmp_name"-$$

mkdir -p "$tmp_name"
chown postgres.postgres "$tmp_name"
chmod 700 "$tmp_name"
echo "DIR: $tmp_name"


if [ ! -z "$server_port" ]; then
    echo "to fetch data from master:$1,port:$2"
    sudo -iu postgres PGPASSWORD=shterm "$BIN_DIR/pg_basebackup" -U postgres -h "$server_ip" -p "$server_port" -D "$tmp_name" -x -P
else
    echo "to fetch data from master:$1"
    sudo -iu postgres PGPASSWORD=shterm "$BIN_DIR/pg_basebackup" -U postgres -h "$server_ip" -D "$tmp_name" -x -P
fi

if [ $? -ne 0 ]; then
    echo "basebackup failed"
    rm -rf "$tmp_name"
    exit 1
fi

if [ -e "$tmp_name/recovery.conf" ]; then 
    echo "to rm recovery.conf"
    rm -f "$tmp_name/recovery.conf"
fi

echo "got data from master"

stop_pg() {
    local data
    local pid
    
    data=`sudo -iu postgres "$BIN_DIR/pg_ctl" -D $DATA_DIR status`
    if [ $? -eq 0 ]; then
        pid=`echo "$data" | awk '/server is running/{print $NF}' | tr -d ')'`
        if [ -z "$pid" ]; then
            echo "no pid?"
            sudo -iu postgres "$BIN_DIR/pg_ctl" -W -D $DATA_DIR stop -m fast
            sleep 3
            return
        fi
        
        echo "to stop pg($pid)..."
        sudo -iu postgres "$BIN_DIR/pg_ctl" -W -D $DATA_DIR stop -m fast
        
        count=10
        while kill -s 0 $pid >/dev/null 2>&1; do
            sleep 1
            count=`expr $count - 1`
            if [ $count -lt 0 ]; then
                echo "stop pg immediate"
                sudo -iu postgres "$BIN_DIR/pg_ctl" -W -D $DATA_DIR stop -m immediate
                return
            fi
        done
    fi
}

# format log to /var/log/shterm/shterm2-ha.log
shterm_log() {
    date_str=`date '+%Y-%m-%d %H:%M:%S,%N'`
    echo $date_str" PG_RESTORE "$* >> /var/log/shterm/shterm2-ha.log
}


if [ $restore -eq 1 ]; then
    stop_pg
    echo "stop pg DONE"
    
    backup_name=`date +"%Y%m%d-%H%M%S"`
    backup_name="${DATA_DIR_BACKUP}_$backup_name"-$$.old
    mv "$DATA_DIR" "$backup_name"
    echo "backup old DB data: $backup_name"
    
    echo "to restore data..."
    mv "$tmp_name" "$DATA_DIR"

    echo "restore DONE"

    echo "delete old backup db data"
    for file_name in `/usr/bin/ls -l --color=auto /var/lib/pgsql/9.6/ | grep data_ | awk -F' ' '{print $NF}' | sort | tac | awk 'NR>2 {print $1}'`
    do
        if [ -d "/var/lib/pgsql/9.6/$file_name" ]; then
            shterm_log "delete backup db data: /var/lib/pgsql/9.6/$file_name"
            rm -rf "/var/lib/pgsql/9.6/$file_name"
        fi
    done
fi
