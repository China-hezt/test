#!/usr/bin/bash

PG_DATA="/var/lib/pgsql/9.6/data"
PG_TMP_DIR="/var/lib/pgsql/9.6/tmpdir"
PG_CONF_REP="$PG_TMP_DIR/rep_mode.conf"
LIBEXEC_DIR="/usr/libexec/shterm"
DEPLOY_TMP="/tmp/shterm_ha_deploy_tmp"
SITE_PKGS="/usr/lib64/python2.7/site-packages"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

chmod +x "$SCRIPT_DIR/ha_init.sh"
chmod +x "$SCRIPT_DIR/install_keys.sh"
chmod +x "$SCRIPT_DIR/hatools"
pg_port_ha=9999
is_master=0
master=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"master"/ {print $4}'`
standby=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"standby"/ {print $4}'`
vip=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"vip"/ {print $4}'`
parent_node_ip=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"parent_node_ip"/ {print $4}'`
nic=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"bind_interface"/ {print $4}'`
mask=`cat "$SCRIPT_DIR/haconfig.tmp" | awk -F'"' '/"mask"/ {print $4}'`
if [ -z "$master" -o -z "standby" ]; then
    echo "config data is invalid"
    exit 1
fi
cat "$SCRIPT_DIR/haconfig.tmp" | grep "is_master" | grep -iq "true"
if [ $? -eq 0 ]; then
    ifconfig | grep -q " $master "
    if [ $? -ne 0 ]; then
        echo "master ip($master) is invalid"
        exit 1
    fi
    
    is_master=1
    
    mkdir "$SCRIPT_DIR/standby_node"
    chmod +x "$SCRIPT_DIR/convert_config"
    "$SCRIPT_DIR"/convert_config  "$SCRIPT_DIR/haconfig.tmp" > "$SCRIPT_DIR/standby_node/haconfig.tmp"
    if [ $? -ne 0 ]; then
        echo "fail to generate config of standby node"
        exit 1
    fi
    
    #cp -f "$SCRIPT_DIR/convert_config"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/deploy.sh"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/undeploy.sh"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/hatools"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/ha_init.sh"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/ha_script"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/pg_conf"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/pg_restore.sh"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/shterm2-ha"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/shterm2-ha.service"  "$SCRIPT_DIR/standby_node/"
    cp -f "$SCRIPT_DIR/install_keys.sh"  "$SCRIPT_DIR/standby_node/"

    if [ -e "$SCRIPT_DIR/upper_node.conf" ]; then
        cp -f "$SCRIPT_DIR/sk.dat"  "$SCRIPT_DIR/standby_node/"
        cp -f "$SCRIPT_DIR/upper_node.conf"  "$SCRIPT_DIR/standby_node/"
    fi

    if [ ! -e "$SCRIPT_DIR/id_rsa" ]; then
        "$SCRIPT_DIR/install_keys.sh" make_key
    else
        "$SCRIPT_DIR/install_keys.sh" copy_key
    fi
    cp /home/shterm/.ssh/id_rsa* /home/shterm/.ssh/authorized_keys "$SCRIPT_DIR/standby_node"
    tar cf standby_node.tar standby_node
    
    firewall-cmd --zone=public --add-rich-rule 'rule family="ipv4" source address="'$standby'" accept'
    firewall-cmd --permanent --zone=public --add-rich-rule 'rule family="ipv4" source address="'$standby'" accept'

    if [ -e "$SCRIPT_DIR/sk.dat" ]; then
        cp -f sk.dat /etc/shterm/
        chown shterm.root /etc/shterm/sk.dat
    fi

    if [ ! -z "$parent_node_ip" ]; then
        # ntp
        echo "server $parent_node_ip iburst" > /etc/shterm/chrony.conf
    fi
else
    ifconfig | grep -q " $standby "
    if [ $? -ne 0 ]; then
        echo "standby ip($standby) is invalid"
        exit 1
    fi
    
    is_master=0

    "$SCRIPT_DIR/install_keys.sh" copy_key
    
    firewall-cmd --zone=public --add-rich-rule 'rule family="ipv4" source address="'$master'" accept'
    firewall-cmd --permanent --zone=public --add-rich-rule 'rule family="ipv4" source address="'$master'" accept'

    if [ -e "$SCRIPT_DIR/sk.dat" ]; then
        cp -f sk.dat /etc/shterm/
        chown shterm.root /etc/shterm/sk.dat
    else
        scp -P 8022  -i /home/shterm/.ssh/id_rsa shterm@$master:/etc/shterm/sk.dat /etc/shterm/sk.dat
    fi

    echo "server $master iburst" > /etc/shterm/chrony.conf

fi

if [ -e "$SCRIPT_DIR/upper_node.conf" ]; then
    IP_ADDRS=`cat "$SCRIPT_DIR/upper_node.conf" | awk -F'=' '/permit_ip/ {print $2}'`
    while IFS=',' read -ra ADDR; do
        for ip_address in "${ADDR[@]}"
        do
            firewall-cmd --zone=public --add-rich-rule 'rule family="ipv4" source address="'$ip_address'" accept'
            firewall-cmd --permanent --zone=public --add-rich-rule 'rule family="ipv4" source address="'$ip_address'" accept'
        done
    done <<< "$IP_ADDRS"
fi

if [ ! -z "$parent_node_ip" ]; then
    firewall-cmd --zone=public --add-rich-rule 'rule family="ipv4" source address="'$parent_node_ip'" accept'
    firewall-cmd --permanent --zone=public --add-rich-rule 'rule family="ipv4" source address="'$parent_node_ip'" accept'
fi

if [ -e "$DEPLOY_TMP" ]; then
    rm -rf "$DEPLOY_TMP"
fi
mkdir "$DEPLOY_TMP"


echo "to config PG"
if [ ! -d "$PG_TMP_DIR" ]; then
    echo "to make tmp dir"
    mkdir "$PG_TMP_DIR"
    chown postgres.postgres "$PG_TMP_DIR"
fi

if [ ! -e "$PG_DATA/postgresql.conf.old" ]; then
    cp "$PG_DATA/postgresql.conf" "$PG_DATA/postgresql.conf.old"
    chown postgres.postgres $PG_DATA/postgresql.conf.old
fi
cat "$SCRIPT_DIR/pg_conf" > "$PG_DATA/postgresql.conf"

install -m 0755  "$SCRIPT_DIR/ha_script" "$LIBEXEC_DIR"
install -m 0755  "$SCRIPT_DIR/pg_restore.sh" "$LIBEXEC_DIR"
install -m 0644 -o shterm -g shterm "$SCRIPT_DIR/haconfig.tmp" /etc/shterm/haconfig
install -m 0755 -o shterm -g shterm "$SCRIPT_DIR/shterm2-ha" "$LIBEXEC_DIR"
install -m 0755 -o shterm -g shterm "$SCRIPT_DIR/hatools" "$LIBEXEC_DIR"


echo "to config sudoer"
grep -q "/usr/libexec/shterm" /etc/sudoers.d/shterm || sed  -i "1 i shterm  ALL=(ALL) NOPASSWD: /usr/libexec/shterm/*" /etc/sudoers.d/shterm

echo "to config redis"
grep -q "^bind 0.0.0.0" /etc/redis.conf || sed -i 's/^bind 127.0.0.1/bind 0.0.0.0/' /etc/redis.conf
systemctl restart redis



"$SCRIPT_DIR"/ha_init.sh
if [ $? -ne 0 ]; then
    echo "ERROR: failed to init ha"
    exit 1
fi

# must be after ha_init.sh because of pg_basebackup will sync postgres.conf from parent node
if [ ! -z "$parent_node_ip" ]; then
    echo "to config shterm.conf"
    $LIBEXEC_DIR/ha_script config_shterm_conf $vip $parent_node_ip
    $LIBEXEC_DIR/ha_script init_db_master $parent_node_ip
else
    if [ $is_master -ne 0 ];then
        $LIBEXEC_DIR/ha_script init_db_master "127.0.0.1:$pg_port_ha"
    else
        $LIBEXEC_DIR/ha_script init_db_master "$master:$pg_port_ha"
    fi
fi




if [ $is_master -ne 0 ];then
    echo "to config service vip"
    BIND_INTERFACE=$nic
    MASK=$mask
    . $LIBEXEC_DIR/ha_script config_master $vip
fi



echo "to config ha service"
if [ -f /usr/lib/systemd/system/shterm2-ha.service ]; then
    systemctl stop shterm2-ha
fi
cp -f "$SCRIPT_DIR/shterm2-ha.service" /usr/lib/systemd/system/
systemctl enable shterm2-ha

echo "to disable pg service"
systemctl stop postgresql-9.6
systemctl disable postgresql-9.6

systemctl daemon-reload
systemctl stop chronyd
systemctl start chronyd

echo "deploy DONE"

