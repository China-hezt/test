#!/usr/bin/bash

PG_DATA="/var/lib/pgsql/9.6/data"
PG_TMP_DIR="/var/lib/pgsql/9.6/tmpdir"
PG_CONF_REP="$PG_TMP_DIR/rep_mode.conf"
LIBEXEC_DIR="/usr/libexec/shterm"
DEPLOY_TMP="/tmp/shterm_ha_deploy_tmp"
SITE_PKGS="/usr/lib64/python2.7/site-packages"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "to undeploy ha service"
if [ -f /usr/lib/systemd/system/shterm2-ha.service ]; then
    systemctl disable shterm2-ha
    systemctl stop shterm2-ha
    rm -rf /usr/lib/systemd/system/shterm2-ha.service
fi

echo "to restore postgresql.conf before deploying ha"
if [ -e "$PG_DATA/postgresql.conf.old" ]; then
    cp -f "$PG_DATA/postgresql.conf.old" "$PG_DATA/postgresql.conf"
    chown postgres.postgres $PG_DATA/postgresql.conf
    rm -rf "$PG_DATA/postgresql.conf.old"
fi

if [ -e "$PG_DATA/recovery.conf" ]; then
    rm -f "$PG_DATA/recovery.conf"
fi

echo "clear redis info"
systemctl stop postgresql-9.6
$SCRIPT_DIR/hatools undeploy

#echo "to delete haconfig"
#if [ -f /etc/shterm/haconfig ]; then
#    rm -rf /etc/shterm/haconfig
#fi
echo "start pg"
systemctl enable postgresql-9.6
systemctl daemon-reload
systemctl start postgresql-9.6

echo "to restart pg and tomcat service"
systemctl restart tomcat
echo "undeploy DONE"

